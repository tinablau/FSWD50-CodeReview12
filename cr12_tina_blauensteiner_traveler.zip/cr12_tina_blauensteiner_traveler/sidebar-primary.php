<?php if ( is_active_sidebar( 'sidebar-post' ) ) : ?>
    <ul id="sidebar">
        <?php dynamic_sidebar( 'sidebar-post' ); ?>
    </ul>
<?php endif; ?>