<?php wp_footer(); ?>
    <footer class="text-muted bg-dark">
		<?php require "nav-footer.php"; ?>
    </footer>
</body>
</html>